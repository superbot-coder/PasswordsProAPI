// Modules.h
// v1.6.1

typedef struct {
	DWORD dwFlags;
	char* szAbout;
	char* szType;
} MODULEINFO;

typedef struct {
	unsigned char* pHash;
	unsigned char* szPassword;
	int nPasswordLen;
	unsigned char* szSalt;
	int nSaltLen;
	unsigned char* szName;
	int nNameLen;
	DWORD dwFlags;
} HASHINFO;

typedef struct
{
	unsigned char* szHash;
	int nHashLen;
	unsigned char* pHash;
	int pHashLen;
	unsigned char* pSalt;
	int pSaltLen;
} PREPAREDINFO;

#define PPF_BINARY_HASH		0x00000001
#define PPF_COMPLEX_HASH	0x00000002

#define PPF_USE_SALT		0x00000100
#define PPF_MD5_SALT		0x00000200

#define PPF_USE_NAME		0x00010000
#define PPF_UNICODE_NAME	0x00020000
#define PPF_LOWER_NAME		0x00800000
#define PPF_UPPER_NAME		0x00C00000

#define PPF_HUGE_PASS		0x01000000
#define PPF_UNICODE_PASS	0x02000000

#define PPF_PREPARED_HASH	0x00000001
